package ru.aimassist;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class AimAssistMod implements ClientModInitializer {
    // ---- Настройки ----
    static final double RANGE = 4.5;          // дальность захвата (блоки)
    static final double FOV = 60.0;           // конус захвата (градусы)
    static final float SMOOTH = 0.35f;        // плавность (0..1), больше = резче

    static boolean enabled = false;
    static boolean includePlayers = true;     // целиться и в игроков (клавиша H переключает)
    static KeyBinding toggleKey;
    static KeyBinding playersKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aimassist.toggle", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R, "category.aimassist"));
        playersKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aimassist.players", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H, "category.aimassist"));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient mc) {
        while (toggleKey.wasPressed()) {          // нажал - вкл, нажал ещё раз - выкл
            enabled = !enabled;
            if (mc.player != null)
                mc.player.sendMessage(Text.literal("AimAssist: " + (enabled ? "ВКЛ" : "ВЫКЛ")), true);
        }
        while (playersKey.wasPressed()) {
            includePlayers = !includePlayers;
            if (mc.player != null)
                mc.player.sendMessage(Text.literal("Игроки: " + (includePlayers ? "ВКЛ" : "ВЫКЛ")), true);
        }
        if (!enabled || mc.player == null || mc.world == null || mc.currentScreen != null) return;

        ClientPlayerEntity p = mc.player;
        Vec3d eye = p.getEyePos();
        double bestAngle = FOV, bestYaw = 0, bestPitch = 0;
        boolean found = false;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
            if (le instanceof PlayerEntity && !includePlayers) continue;
            Vec3d t = le.getBoundingBox().getCenter();   // центр хитбокса
            if (eye.distanceTo(t) > RANGE || !p.canSee(le)) continue;

            Vec3d d = t.subtract(eye);
            double yawT = Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0;
            double pitchT = -Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)));
            double dy = MathHelper.wrapDegrees(yawT - p.getYaw());
            double dp = pitchT - p.getPitch();
            double angle = Math.hypot(dy, dp);
            if (angle < bestAngle) { bestAngle = angle; bestYaw = dy; bestPitch = dp; found = true; }
        }
        if (found) {
            p.setYaw(p.getYaw() + (float) bestYaw * SMOOTH);
            p.setPitch(MathHelper.clamp(p.getPitch() + (float) bestPitch * SMOOTH, -90f, 90f));
        }
    }
}
